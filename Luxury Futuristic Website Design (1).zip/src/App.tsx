import { BrandShowcase } from "./components/BrandShowcase";
import { MembershipTiers } from "./components/MembershipTiers";
import { IconShowcase } from "./components/IconShowcase";
import { LiquidDivider } from "./components/LiquidDivider";
import { ParticleBackground } from "./components/ParticleBackground";
import { Navigation } from "./components/Navigation";
import { ContactSection } from "./components/ContactSection";
import { SignupFlow } from "./components/SignupFlow";
import { MemberDashboard } from "./components/MemberDashboard";
import { ProductsSection } from "./components/ProductsSection";
import { Footer } from "./components/Footer";
import { PrivacyPolicy } from "./components/PrivacyPolicy";
import { FAQ } from "./components/FAQ";
import { useState } from "react";

type MembershipTier = "gold" | "black";

export default function App() {
  const [view, setView] = useState<
    | "home"
    | "signup"
    | "dashboard"
    | "privacy"
    | "faq"
    | "contact"
  >("home");
  const [selectedTier, setSelectedTier] =
    useState<MembershipTier>("gold");
  const [cart, setCart] = useState<{ [key: string]: number }>(
    {},
  );

  const handleJoinClick = (tier: MembershipTier) => {
    setSelectedTier(tier);
    setView("signup");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const addToCart = (productId: string) => {
    setCart((prev) => ({
      ...prev,
      [productId]: (prev[productId] || 0) + 1,
    }));
  };

  const cartCount = Object.values(cart).reduce(
    (a, b) => a + b,
    0,
  );

  const handleNavigate = (
    page: "privacy" | "faq" | "contact",
  ) => {
    setView(page);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleCartClick = () => {
    // Scroll to products section
    setView("home");
    setTimeout(() => {
      const productsSection =
        document.getElementById("products");
      productsSection?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  return (
    <div className="relative min-h-screen bg-black overflow-hidden">
      <ParticleBackground />

      {view === "home" && (
        <div className="relative z-10">
          <Navigation
            cartCount={cartCount}
            onCartClick={handleCartClick}
            onNavigate={handleNavigate}
          />

          <BrandShowcase />

          <LiquidDivider />

          <div id="membership">
            <MembershipTiers onJoinClick={handleJoinClick} />
          </div>

          <LiquidDivider variant="reverse" />

          <div id="products">
            <ProductsSection addToCart={addToCart} />
          </div>

          <LiquidDivider />

          <IconShowcase />

          <LiquidDivider />

          <div id="contact">
            <ContactSection />
          </div>

          <Footer
            cartCount={cartCount}
            onCartClick={handleCartClick}
            onNavigate={handleNavigate}
          />
        </div>
      )}

      {view === "signup" && (
        <div className="relative z-10">
          <SignupFlow
            initialTier={selectedTier}
            onBack={() => setView("home")}
          />
        </div>
      )}

      {view === "dashboard" && (
        <div className="relative z-10">
          <MemberDashboard />
        </div>
      )}

      {view === "privacy" && (
        <div className="relative z-10">
          <PrivacyPolicy onBack={() => setView("home")} />
        </div>
      )}

      {view === "faq" && (
        <div className="relative z-10">
          <FAQ onBack={() => setView("home")} />
        </div>
      )}

      {view === "contact" && (
        <div className="relative z-10">
          <Navigation
            cartCount={cartCount}
            onCartClick={handleCartClick}
            onNavigate={handleNavigate}
          />
          <div className="pt-32">
            <ContactSection />
          </div>
          <Footer
            cartCount={cartCount}
            onCartClick={handleCartClick}
            onNavigate={handleNavigate}
          />
        </div>
      )}
    </div>
  );
}