import { motion } from "motion/react";
import image1 from "figma:asset/4619b08055bd39b2ba2bf409b3ef4c4cc5127974.png";
import image2 from "figma:asset/19052af3ddfaad63c59c9bb0c92c8d972b0c53ec.png";

export function BrandShowcase() {
  return (
    <section id="home" className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16 space-y-4"
        >
          <h2 className="text-5xl md:text-6xl text-white font-serif tracking-[0.2em] uppercase">
            Welcome to Elxar
          </h2>
          <div className="h-px bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent max-w-md mx-auto" />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Image 1 */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative group"
          >
            <div 
              className="relative overflow-hidden rounded-2xl"
              style={{
                background: "rgba(255, 255, 255, 0.03)",
                backdropFilter: "blur(20px)",
                border: "1px solid rgba(212, 175, 55, 0.2)",
                boxShadow: "0 8px 32px 0 rgba(0, 0, 0, 0.4)"
              }}
            >
              <img
                src={image1}
                alt="ELXAR Fragrance Collection"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              
              {/* Glass Overlay */}
              <div 
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{
                  background: "linear-gradient(135deg, rgba(212, 175, 55, 0.1) 0%, transparent 50%)",
                }}
              />
            </div>
          </motion.div>

          {/* Image 2 */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="relative group"
          >
            <div 
              className="relative overflow-hidden rounded-2xl"
              style={{
                background: "rgba(255, 255, 255, 0.03)",
                backdropFilter: "blur(20px)",
                border: "1px solid rgba(212, 175, 55, 0.2)",
                boxShadow: "0 8px 32px 0 rgba(0, 0, 0, 0.4)"
              }}
            >
              <img
                src={image2}
                alt="ELXAR Membership Card"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              
              {/* Glass Overlay */}
              <div 
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{
                  background: "linear-gradient(135deg, rgba(229, 195, 127, 0.1) 0%, transparent 50%)",
                }}
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}