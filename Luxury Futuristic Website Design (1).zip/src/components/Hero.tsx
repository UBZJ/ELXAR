import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { FloatingEmblem } from "./FloatingEmblem";
import { ChevronDown } from "lucide-react";
import heroBackground from "figma:asset/a6756e913b8dcf1bbc31798cb3f1415b3b959918.png";

interface HeroProps {
  onJoinClick?: (tier: "gold" | "black") => void;
}

export function Hero({ onJoinClick }: HeroProps) {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"]
  });
  
  const y = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <section ref={ref} className="relative min-h-screen flex items-center justify-center px-6 pt-24">
      {/* Background image removed */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Background Image */}
        <motion.div 
          style={{ y }}
          className="absolute inset-0"
        >
          {/* Background image removed */}
        </motion.div>
        
        {/* Liquid Glass Overlay removed */}
      </div>

      <motion.div 
        style={{ y, opacity }}
        className="text-center space-y-12 max-w-5xl mx-auto relative z-10"
      >
        <FloatingEmblem />
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="space-y-8"
        >
          <div className="space-y-4">
            {/* ELXAR heading removed */}
            
            <div className="h-px bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent max-w-md mx-auto" />
            
            {/* Tagline removed */}
          </div>
          
          {/* Buttons removed */}
        </motion.div>
        
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="pt-12"
        >
          <ChevronDown className="w-8 h-8 text-[#D4AF37] mx-auto" />
        </motion.div>
      </motion.div>
    </section>
  );
}