import { motion } from "motion/react";
import { useEffect, useState } from "react";
import logo from "figma:asset/bd97e12a8d048c1c32cdddf8e30c6d2dc3b41f46.png";

export function FloatingEmblem() {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: (e.clientX - window.innerWidth / 2) / 50,
        y: (e.clientY - window.innerHeight / 2) / 50
      });
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return (
    null
  );
}