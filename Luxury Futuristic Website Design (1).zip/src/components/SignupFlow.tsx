import { motion } from "motion/react";
import { useState } from "react";
import { Check, Lock, CreditCard, AppleIcon, Smartphone } from "lucide-react";

type SignupStep = "account" | "payment" | "confirmation";
type MembershipTier = "gold" | "black";

interface SignupFlowProps {
  initialTier?: MembershipTier;
  onBack?: () => void;
}

export function SignupFlow({ initialTier = "gold", onBack }: SignupFlowProps) {
  const [step, setStep] = useState<SignupStep>("account");
  const [tier, setTier] = useState<MembershipTier>(initialTier);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    country: "",
    ageConfirmed: false
  });

  const handleAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep("payment");
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep("confirmation");
  };

  return (
    <section className="py-32 px-6 min-h-screen flex items-center justify-center">
      <div className="max-w-2xl w-full mx-auto">
        {/* Progress Indicator */}
        <div className="flex items-center justify-center mb-12 gap-4">
          {["account", "payment", "confirmation"].map((s, i) => (
            <div key={s} className="flex items-center">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 ${
                  step === s
                    ? "bg-[#D4AF37] text-[#0A0A0A]"
                    : i < ["account", "payment", "confirmation"].indexOf(step)
                    ? "bg-[#D4AF37]/50 text-white"
                    : "bg-[#161616] text-[#E5C37F]/50 border border-[#D4AF37]/30"
                }`}
              >
                {i < ["account", "payment", "confirmation"].indexOf(step) ? (
                  <Check className="w-5 h-5" />
                ) : (
                  <span>{i + 1}</span>
                )}
              </div>
              {i < 2 && (
                <div className={`w-20 h-px mx-2 ${
                  i < ["account", "payment", "confirmation"].indexOf(step)
                    ? "bg-[#D4AF37]"
                    : "bg-[#D4AF37]/30"
                }`} />
              )}
            </div>
          ))}
        </div>

        {/* Step 1: Create Account */}
        {step === "account" && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="glass-panel p-8"
          >
            <h2 className="text-4xl text-white font-serif mb-2 text-center">
              Create Your Account
            </h2>
            <p className="text-[#E5C37F]/70 text-center mb-8">
              Join ELXAR {tier === "gold" ? "Gold" : "Black"} Membership
            </p>

            {/* Tier Selection */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              <button
                onClick={() => setTier("gold")}
                className={`p-4 rounded-xl transition-all duration-300 ${
                  tier === "gold"
                    ? "bg-[#D4AF37]/20 border-2 border-[#D4AF37]"
                    : "bg-[#161616] border border-[#D4AF37]/30"
                }`}
              >
                <p className="text-[#E5C37F]">Gold</p>
                <p className="text-2xl text-[#D4AF37]">£40/mo</p>
              </button>
              <button
                onClick={() => setTier("black")}
                className={`p-4 rounded-xl transition-all duration-300 ${
                  tier === "black"
                    ? "bg-[#D4AF37]/20 border-2 border-[#D4AF37]"
                    : "bg-[#161616] border border-[#D4AF37]/30"
                }`}
              >
                <p className="text-[#E5C37F]">Black</p>
                <p className="text-2xl text-[#D4AF37]">£80/mo</p>
              </button>
            </div>

            <form onSubmit={handleAccountSubmit} className="space-y-5">
              <input
                type="text"
                placeholder="Full Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-6 py-4 rounded-xl bg-[#1A1A1A] border border-[#D4AF37]/30 text-[#E5C37F] placeholder:text-[#E5C37F]/50 focus:outline-none focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20 transition-all"
                required
              />
              <input
                type="email"
                placeholder="Email Address"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-6 py-4 rounded-xl bg-[#1A1A1A] border border-[#D4AF37]/30 text-[#E5C37F] placeholder:text-[#E5C37F]/50 focus:outline-none focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20 transition-all"
                required
              />
              <input
                type="password"
                placeholder="Password"
                value={formData.password}
                onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                className="w-full px-6 py-4 rounded-xl bg-[#1A1A1A] border border-[#D4AF37]/30 text-[#E5C37F] placeholder:text-[#E5C37F]/50 focus:outline-none focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20 transition-all"
                required
              />
              <input
                type="text"
                placeholder="Country"
                value={formData.country}
                onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                className="w-full px-6 py-4 rounded-xl bg-[#1A1A1A] border border-[#D4AF37]/30 text-[#E5C37F] placeholder:text-[#E5C37F]/50 focus:outline-none focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20 transition-all"
                required
              />
              
              <label className="flex items-start gap-3 text-[#E5C37F]/80 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.ageConfirmed}
                  onChange={(e) => setFormData({ ...formData, ageConfirmed: e.target.checked })}
                  className="mt-1 w-4 h-4 accent-[#D4AF37]"
                  required
                />
                <span className="text-sm">
                  I confirm that I am 18 years or older and agree to the Terms of Service and Privacy Policy
                </span>
              </label>

              <motion.button
                type="submit"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full glass-button mt-6"
                style={{
                  background: "linear-gradient(135deg, rgba(212, 175, 55, 0.2), rgba(229, 195, 127, 0.1))",
                  border: "1px solid rgba(212, 175, 55, 0.5)"
                }}
              >
                Continue to Payment
              </motion.button>
            </form>
          </motion.div>
        )}

        {/* Step 2: Payment */}
        {step === "payment" && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="glass-panel p-8"
          >
            <div className="flex items-center justify-center gap-2 mb-6">
              <Lock className="w-5 h-5 text-[#D4AF37]" />
              <h2 className="text-4xl text-white font-serif">
                Secure Payment
              </h2>
            </div>
            
            <div className="bg-[#161616] p-6 rounded-xl mb-8 border border-[#D4AF37]/30">
              <div className="flex justify-between items-center mb-2">
                <span className="text-[#E5C37F]">ELXAR {tier === "gold" ? "Gold" : "Black"}</span>
                <span className="text-[#D4AF37] text-2xl">
                  £{tier === "gold" ? "40" : "80"}/month
                </span>
              </div>
              <p className="text-xs text-[#E5C37F]/50">
                Billing renews monthly. Cancel anytime.
              </p>
            </div>

            <form onSubmit={handlePaymentSubmit} className="space-y-5">
              {/* Payment Method Buttons */}
              <div className="space-y-3">
                <button
                  type="button"
                  className="w-full flex items-center justify-center gap-3 px-6 py-4 rounded-xl bg-[#1A1A1A] border border-[#D4AF37]/30 text-[#E5C37F] hover:border-[#D4AF37] transition-all"
                >
                  <CreditCard className="w-5 h-5" />
                  <span>Credit / Debit Card</span>
                </button>
                
                <button
                  type="button"
                  className="w-full flex items-center justify-center gap-3 px-6 py-4 rounded-xl bg-[#1A1A1A] border border-[#D4AF37]/30 text-[#E5C37F] hover:border-[#D4AF37] transition-all"
                >
                  <div className="w-5 h-5 bg-black rounded flex items-center justify-center">
                    <AppleIcon className="w-4 h-4 text-white" />
                  </div>
                  <span>Apple Pay</span>
                </button>
                
                <button
                  type="button"
                  className="w-full flex items-center justify-center gap-3 px-6 py-4 rounded-xl bg-[#1A1A1A] border border-[#D4AF37]/30 text-[#E5C37F] hover:border-[#D4AF37] transition-all"
                >
                  <Smartphone className="w-5 h-5" />
                  <span>Google Pay</span>
                </button>
              </div>

              <div className="text-center text-xs text-[#E5C37F]/60 py-4">
                <Lock className="w-4 h-4 inline-block mr-1" />
                Payments secured by Stripe. Your data is encrypted and protected.
              </div>

              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setStep("account")}
                  className="flex-1 px-6 py-4 rounded-full border border-[#D4AF37]/40 text-[#E5C37F] hover:border-[#D4AF37] transition-all"
                >
                  Back
                </button>
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="flex-1 glass-button"
                  style={{
                    background: "linear-gradient(135deg, rgba(212, 175, 55, 0.2), rgba(229, 195, 127, 0.1))",
                    border: "1px solid rgba(212, 175, 55, 0.5)"
                  }}
                >
                  Complete Payment
                </motion.button>
              </div>
            </form>
          </motion.div>
        )}

        {/* Step 3: Confirmation */}
        {step === "confirmation" && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass-panel p-12 text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1, rotate: 360 }}
              transition={{ type: "spring", stiffness: 200, damping: 15 }}
              className="w-24 h-24 mx-auto mb-8 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#E5C37F] flex items-center justify-center"
            >
              <Check className="w-12 h-12 text-[#0A0A0A]" />
            </motion.div>

            <h2 className="text-5xl text-white font-serif mb-4">
              Welcome to ELXAR
            </h2>
            <p className="text-xl text-[#E5C37F] mb-8">
              You're now an ELXAR {tier === "gold" ? "Gold" : "Black"} member
            </p>

            <div className="glass-panel p-6 mb-8 inline-block">
              <motion.div
                animate={{ rotateY: [0, 360] }}
                transition={{ duration: 2, ease: "easeInOut" }}
                className="w-64 h-40 rounded-xl relative overflow-hidden"
                style={{
                  background: tier === "black" 
                    ? "linear-gradient(135deg, rgba(212, 175, 55, 0.3), rgba(229, 195, 127, 0.2))"
                    : "linear-gradient(135deg, rgba(212, 175, 55, 0.15), rgba(229, 195, 127, 0.1))",
                  border: "1px solid rgba(212, 175, 55, 0.5)",
                  backdropFilter: "blur(20px)"
                }}
              >
                <div className="absolute inset-0 p-6 flex flex-col justify-between">
                  <div className="text-left">
                    <p className="text-xs text-[#E5C37F]/70">MEMBER SINCE 2025</p>
                    <p className="text-2xl text-white font-serif mt-1">ELXAR</p>
                  </div>
                  <div className="text-right">
                    <p className="text-lg text-[#D4AF37]">{tier === "gold" ? "GOLD" : "BLACK"}</p>
                    <p className="text-sm text-[#E5C37F]/80">{formData.name}</p>
                  </div>
                </div>
              </motion.div>
            </div>

            <div className="space-y-4 text-[#E5C37F]/80 mb-8">
              <p>✓ Confirmation email sent to {formData.email}</p>
              <p>✓ Access to member dashboard</p>
              <p>✓ Digital membership card available</p>
            </div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="glass-button"
              style={{
                background: "linear-gradient(135deg, rgba(212, 175, 55, 0.2), rgba(229, 195, 127, 0.1))",
                border: "1px solid rgba(212, 175, 55, 0.5)"
              }}
            >
              Go to Dashboard
            </motion.button>
          </motion.div>
        )}
      </div>
    </section>
  );
}