import { motion } from "motion/react";
import { Menu, X, ShoppingCart } from "lucide-react";
import { useState } from "react";
import logo from "figma:asset/bd97e12a8d048c1c32cdddf8e30c6d2dc3b41f46.png";

interface NavigationProps {
  cartCount?: number;
  onCartClick?: () => void;
  onNavigate?: (page: "privacy" | "faq" | "contact") => void;
}

const navItems = [
  { label: "Home", href: "#home" },
  { label: "Membership", href: "#membership" },
  { label: "Products", href: "#products" },
  { label: "Contact", href: "#contact" },
];

export function Navigation({ cartCount = 0, onCartClick, onNavigate }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string, label: string) => {
    e.preventDefault();
    
    if (label === "Contact" && onNavigate) {
      onNavigate("contact");
      setIsOpen(false);
      return;
    }

    // Smooth scroll to section
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: "smooth", block: "start" });
      setIsOpen(false);
    }
  };

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="fixed top-0 left-0 right-0 z-50 px-6 py-4"
      >
        <div className="max-w-7xl mx-auto">
          <div 
            className="glass-panel px-6 py-3"
            style={{
              background: "rgba(10, 10, 10, 0.8)",
              backdropFilter: "blur(40px)",
              borderRadius: "9999px"
            }}
          >
            <div className="flex items-center justify-between">
              {/* Logo */}
              <motion.a
                href="#home"
                className="flex items-center gap-3"
                whileHover={{ scale: 1.05 }}
                onClick={(e) => {
                  e.preventDefault();
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
              >
                <img 
                  src={logo} 
                  alt="ELXAR" 
                  className="h-12 w-auto"
                  style={{
                    filter: "drop-shadow(0 0 10px rgba(212,175,55,0.4))"
                  }}
                />
              </motion.a>

              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center gap-8">
                {navItems.map((item) => (
                  <motion.a
                    key={item.label}
                    href={item.href}
                    className="text-[#E5C37F] hover:text-[#D4AF37] transition-colors relative group"
                    whileHover={{ scale: 1.05 }}
                    onClick={(e) => handleNavClick(e, item.href, item.label)}
                  >
                    {item.label}
                    <span className="absolute -bottom-1 left-0 w-0 h-px bg-[#D4AF37] group-hover:w-full transition-all duration-300" />
                  </motion.a>
                ))}
                
                {/* Cart Icon */}
                {onCartClick && (
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={onCartClick}
                    className="relative text-[#E5C37F] hover:text-[#D4AF37] transition-colors"
                  >
                    <ShoppingCart className="w-6 h-6" />
                    {cartCount > 0 && (
                      <span className="absolute -top-2 -right-2 bg-[#D4AF37] text-black text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                        {cartCount}
                      </span>
                    )}
                  </motion.button>
                )}
              </div>

              {/* Mobile Menu Button */}
              <div className="flex items-center gap-4 md:hidden">
                {onCartClick && (
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={onCartClick}
                    className="relative text-[#E5C37F] hover:text-[#D4AF37] transition-colors"
                  >
                    <ShoppingCart className="w-6 h-6" />
                    {cartCount > 0 && (
                      <span className="absolute -top-2 -right-2 bg-[#D4AF37] text-black text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
                        {cartCount}
                      </span>
                    )}
                  </motion.button>
                )}
                <button
                  onClick={() => setIsOpen(!isOpen)}
                  className="text-[#E5C37F]"
                >
                  {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="fixed top-24 left-6 right-6 z-40 md:hidden"
        >
          <div 
            className="glass-panel p-6 space-y-4"
            style={{
              background: "rgba(10, 10, 10, 0.95)",
              backdropFilter: "blur(40px)"
            }}
          >
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="block text-[#E5C37F] hover:text-[#D4AF37] transition-colors py-2"
                onClick={(e) => handleNavClick(e, item.href, item.label)}
              >
                {item.label}
              </a>
            ))}
          </div>
        </motion.div>
      )}
    </>
  );
}