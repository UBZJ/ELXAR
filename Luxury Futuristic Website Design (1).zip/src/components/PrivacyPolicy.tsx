import { motion } from "motion/react";
import { ArrowLeft } from "lucide-react";

interface PrivacyPolicyProps {
  onBack: () => void;
}

export function PrivacyPolicy({ onBack }: PrivacyPolicyProps) {
  return (
    <section className="min-h-screen py-32 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Back Button */}
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={onBack}
          className="flex items-center gap-2 text-[#D4AF37] hover:text-[#E5C37F] transition-colors mb-12"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Home</span>
        </motion.button>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="font-serif text-5xl md:text-6xl mb-4">
            <span className="bg-gradient-to-r from-[#E5C37F] via-[#D4AF37] to-[#E5C37F] bg-clip-text text-transparent">
              Privacy Policy
            </span>
          </h1>
          <div className="h-px bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent max-w-md mx-auto" />
        </motion.div>

        {/* Content */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-8 text-[#E5C37F]/80"
          style={{
            background: "rgba(22, 22, 22, 0.6)",
            backdropFilter: "blur(40px)",
            border: "1px solid rgba(212, 175, 55, 0.2)",
            borderRadius: "1.5rem",
            padding: "3rem"
          }}
        >
          <div>
            <h2 className="text-2xl font-serif text-[#D4AF37] mb-4">Information We Collect</h2>
            <p className="leading-relaxed">
              At ELXAR, we value your privacy and are committed to protecting your personal information. We collect information that you provide directly to us when you create an account, make a purchase, or interact with our services.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-serif text-[#D4AF37] mb-4">How We Use Your Information</h2>
            <p className="leading-relaxed">
              Your information is used to process orders, provide personalized recommendations, improve our services, and communicate with you about your membership and our exclusive offerings.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-serif text-[#D4AF37] mb-4">Data Security</h2>
            <p className="leading-relaxed">
              We implement industry-standard security measures to protect your personal information. All payment processing is handled through secure, encrypted channels.
            </p>
          </div>

          <div>
            <h2 className="text-2xl font-serif text-[#D4AF37] mb-4">Your Rights</h2>
            <p className="leading-relaxed">
              You have the right to access, correct, or delete your personal information at any time. Contact our support team to exercise these rights or for any privacy-related inquiries.
            </p>
          </div>

          <div className="pt-6 border-t border-[#D4AF37]/20">
            <p className="text-sm text-[#E5C37F]/60">
              Last updated: November 19, 2025
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
