import { motion } from "motion/react";

interface LiquidDividerProps {
  variant?: "default" | "reverse";
}

export function LiquidDivider({ variant = "default" }: LiquidDividerProps) {
  return (
    <div className="relative h-32 overflow-hidden flex items-center justify-center px-6">
      {/* Main glowing line */}
      <div className="relative w-full max-w-4xl h-[2px]">
        {/* Base glass line */}
        <div 
          className="absolute inset-0 rounded-full"
          style={{
            background: "linear-gradient(90deg, transparent, rgba(212,175,55,0.4) 20%, rgba(229,195,127,0.6) 50%, rgba(212,175,55,0.4) 80%, transparent)",
            backdropFilter: "blur(20px)",
            boxShadow: `
              0 0 20px rgba(212,175,55,0.6),
              0 0 40px rgba(212,175,55,0.3),
              0 0 60px rgba(212,175,55,0.1)
            `
          }}
        />
        
        {/* Animated glow pulse */}
        <motion.div
          animate={{
            opacity: [0.4, 0.8, 0.4],
            scale: [1, 1.2, 1]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute inset-0 rounded-full"
          style={{
            background: "linear-gradient(90deg, transparent, rgba(229,195,127,0.5) 40%, rgba(212,175,55,0.7) 50%, rgba(229,195,127,0.5) 60%, transparent)",
            filter: "blur(10px)"
          }}
        />
        
        {/* Flowing shimmer */}
        <motion.div
          animate={{ x: ["-100%", "200%"] }}
          transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
          className="absolute top-1/2 -translate-y-1/2 h-[4px] w-1/4 rounded-full"
          style={{
            background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.8), rgba(229,195,127,0.9), rgba(255,255,255,0.8), transparent)",
            boxShadow: "0 0 20px rgba(229,195,127,0.8)",
            filter: "blur(2px)"
          }}
        />
      </div>
    </div>
  );
}