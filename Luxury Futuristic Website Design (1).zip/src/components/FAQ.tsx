import { motion } from "motion/react";
import { ArrowLeft, ChevronDown } from "lucide-react";
import { useState } from "react";

interface FAQProps {
  onBack: () => void;
}

interface FAQItem {
  question: string;
  answer: string;
}

const faqData: FAQItem[] = [
  {
    question: "What is ELXAR membership?",
    answer: "ELXAR membership provides exclusive access to our luxury fragrance collection, personalized consultations, early access to limited editions, and special member-only events. Choose between ELXAR Gold (£40/month) and ELXAR Black (£80/month) tiers."
  },
  {
    question: "What are the differences between Gold and Black membership?",
    answer: "ELXAR Black members enjoy all Gold benefits plus priority access to exclusive launches, complimentary concierge services, private shopping experiences, and invitations to VIP events. Black members also receive higher discounts on purchases."
  },
  {
    question: "How do I cancel my membership?",
    answer: "You can cancel your membership at any time through your member dashboard. Your membership will remain active until the end of your current billing period. No questions asked, no hidden fees."
  },
  {
    question: "Do you ship internationally?",
    answer: "Yes, we ship worldwide. Shipping costs and delivery times vary by location. All international orders are shipped via premium courier services with full tracking and insurance."
  },
  {
    question: "What is your return policy?",
    answer: "We offer a 30-day return policy on all unopened products. If you're not completely satisfied, contact our concierge team for a hassle-free return or exchange."
  },
  {
    question: "How are the fragrances sourced?",
    answer: "Our fragrances are crafted using the finest ingredients sourced from renowned perfume houses across the globe. Each scent undergoes rigorous quality testing to ensure it meets ELXAR's exacting standards."
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept all major credit cards, debit cards, and secure digital payment methods. All transactions are encrypted and processed through secure payment gateways."
  }
];

export function FAQ({ onBack }: FAQProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <section className="min-h-screen py-32 px-6">
      <div className="max-w-4xl mx-auto">
        {/* Back Button */}
        <motion.button
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          onClick={onBack}
          className="flex items-center gap-2 text-[#D4AF37] hover:text-[#E5C37F] transition-colors mb-12"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back to Home</span>
        </motion.button>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="font-serif text-5xl md:text-6xl mb-4">
            <span className="bg-gradient-to-r from-[#E5C37F] via-[#D4AF37] to-[#E5C37F] bg-clip-text text-transparent">
              Most Asked Questions
            </span>
          </h1>
          <div className="h-px bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent max-w-md mx-auto mb-6" />
          <p className="text-[#E5C37F]/80">
            Everything you need to know about ELXAR membership and our luxury fragrances
          </p>
        </motion.div>

        {/* FAQ Items */}
        <div className="space-y-4">
          {faqData.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="overflow-hidden rounded-xl"
              style={{
                background: "rgba(22, 22, 22, 0.6)",
                backdropFilter: "blur(40px)",
                border: "1px solid rgba(212, 175, 55, 0.2)",
              }}
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full px-6 py-5 flex items-center justify-between text-left hover:bg-[#D4AF37]/5 transition-colors"
              >
                <span className="text-[#E5C37F] text-lg pr-4">{item.question}</span>
                <motion.div
                  animate={{ rotate: openIndex === index ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <ChevronDown className="w-5 h-5 text-[#D4AF37] flex-shrink-0" />
                </motion.div>
              </button>
              
              <motion.div
                initial={false}
                animate={{
                  height: openIndex === index ? "auto" : 0,
                  opacity: openIndex === index ? 1 : 0
                }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="px-6 pb-5 text-[#E5C37F]/70 leading-relaxed border-t border-[#D4AF37]/10 pt-4">
                  {item.answer}
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Contact CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-12 text-center p-8 rounded-xl"
          style={{
            background: "linear-gradient(135deg, rgba(212, 175, 55, 0.1), rgba(229, 195, 127, 0.05))",
            border: "1px solid rgba(212, 175, 55, 0.3)",
          }}
        >
          <p className="text-[#E5C37F] mb-4">
            Still have questions?
          </p>
          <p className="text-[#E5C37F]/70">
            Our concierge team is available 24/7 to assist you. Contact us anytime.
          </p>
        </motion.div>
      </div>
    </section>
  );
}