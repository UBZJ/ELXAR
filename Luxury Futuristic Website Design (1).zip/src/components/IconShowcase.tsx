import { motion } from "motion/react";
import { Crown, Droplet, Key, Shield } from "lucide-react";

const icons = [
  { Icon: Crown, label: "Luxury", rotation: [0, 360] },
  { Icon: Droplet, label: "Exclusivity", rotation: [0, -360] },
  { Icon: Key, label: "Access", rotation: [360, 0] },
  { Icon: Shield, label: "Privacy", rotation: [-360, 0] }
];

export function IconShowcase() {
  return (
    <section className="py-32 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-20">
          <h2 className="text-5xl md:text-6xl text-white font-serif mb-4">
            The ELXAR Promise
          </h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {icons.map(({ Icon, label, rotation }, index) => (
            <motion.div
              key={label}
              initial={{ opacity: 0, scale: 0.5 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
              className="flex flex-col items-center gap-6"
            >
              <motion.div
                whileHover={{ 
                  scale: 1.1,
                  rotateY: 180
                }}
                transition={{ type: "spring", stiffness: 200, damping: 15 }}
                className="relative w-32 h-32"
                style={{ transformStyle: "preserve-3d" }}
              >
                {/* Glass cube */}
                <div 
                  className="absolute inset-0 rounded-2xl"
                  style={{
                    background: "rgba(255,255,255,0.03)",
                    backdropFilter: "blur(30px)",
                    border: "1px solid rgba(212,175,55,0.3)",
                    boxShadow: `
                      0 8px 32px 0 rgba(212,175,55,0.2),
                      inset 0 2px 20px 0 rgba(255,255,255,0.05)
                    `
                  }}
                />
                
                {/* Floating icon */}
                <motion.div
                  animate={{ 
                    y: [0, -10, 0],
                    rotateZ: rotation
                  }}
                  transition={{ 
                    y: { duration: 3, repeat: Infinity, ease: "easeInOut" },
                    rotateZ: { duration: 20, repeat: Infinity, ease: "linear" }
                  }}
                  className="absolute inset-0 flex items-center justify-center"
                >
                  <Icon 
                    className="w-16 h-16 text-[#D4AF37]"
                    style={{
                      filter: "drop-shadow(0 0 20px rgba(212,175,55,0.8))"
                    }}
                  />
                </motion.div>
                
                {/* Reflection */}
                <div 
                  className="absolute inset-0 rounded-2xl"
                  style={{
                    background: "linear-gradient(135deg, rgba(255,255,255,0.1) 0%, transparent 50%)"
                  }}
                />
              </motion.div>
              
              <p className="text-xl text-[#E5C37F]">{label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
