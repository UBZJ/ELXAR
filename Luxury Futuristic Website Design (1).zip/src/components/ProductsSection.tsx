import { motion } from "motion/react";
import { ShoppingCart, Star } from "lucide-react";
import { useState } from "react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  rating: number;
  category: string;
  featured?: boolean;
}

// Sample products - replace with your actual products
const sampleProducts: Product[] = [
  {
    id: "1",
    name: "ELXAR Noir",
    description: "A sophisticated blend of oud, amber, and vanilla. The signature scent of prestige.",
    price: 149.99,
    image: "luxury perfume",
    rating: 5,
    category: "Signature Collection",
    featured: true
  },
  {
    id: "2",
    name: "ELXAR Royal",
    description: "Exquisite notes of saffron, leather, and sandalwood. For the discerning elite.",
    price: 189.99,
    image: "luxury fragrance",
    rating: 5,
    category: "Premium Collection",
    featured: true
  },
  {
    id: "3",
    name: "ELXAR Prestige",
    description: "A luxurious fusion of bergamot, rose, and musk. Timeless elegance redefined.",
    price: 169.99,
    image: "premium perfume",
    rating: 5,
    category: "Signature Collection"
  },
  {
    id: "4",
    name: "ELXAR Gold Edition",
    description: "Limited edition with 24k gold flakes. Pure opulence in every spray.",
    price: 299.99,
    image: "gold perfume bottle",
    rating: 5,
    category: "Limited Edition",
    featured: true
  },
  {
    id: "5",
    name: "ELXAR Black Diamond",
    description: "Rare ingredients from across the globe. The pinnacle of luxury fragrance.",
    price: 499.99,
    image: "black luxury perfume",
    rating: 5,
    category: "Exclusive Collection",
    featured: true
  },
  {
    id: "6",
    name: "ELXAR Velvet",
    description: "Smooth notes of iris, tonka bean, and cashmere. Sophisticated refinement.",
    price: 159.99,
    image: "velvet perfume",
    rating: 5,
    category: "Premium Collection"
  }
];

interface ProductsSectionProps {
  addToCart: (productId: string) => void;
}

export function ProductsSection({ addToCart }: ProductsSectionProps) {
  const [filter, setFilter] = useState<string>("all");

  const categories = ["Signature Collection"];
  const filteredProducts = filter === "all" 
    ? sampleProducts 
    : sampleProducts.filter(p => p.category === filter);

  return (
    <section className="relative py-32 px-6 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0">
        <motion.div
          className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full"
          style={{
            background: "radial-gradient(circle, rgba(212, 175, 55, 0.08), transparent 70%)",
            filter: "blur(60px)"
          }}
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-block mb-4"
          >
            <span className="text-[#D4AF37] tracking-[0.3em] uppercase text-sm">
              Exclusive Collection
            </span>
          </motion.div>
          
          <h2 className="font-serif text-5xl md:text-6xl lg:text-7xl mb-6">
            <span className="bg-gradient-to-r from-[#E5C37F] via-[#D4AF37] to-[#E5C37F] bg-clip-text text-transparent">
              ELXAR ADVISORY FRAGRANCES
            </span>
          </h2>
          
          <p className="text-[#E5C37F]/80 max-w-2xl mx-auto text-lg">
            Discover our curated collection of premium fragrances, each crafted to perfection for the modern connoisseur.
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex flex-wrap justify-center gap-3 mb-12"
        >
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setFilter(category)}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                filter === category
                  ? "bg-[#D4AF37] text-black"
                  : "bg-[#161616] text-[#E5C37F] border border-[#D4AF37]/30 hover:border-[#D4AF37]/60"
              }`}
            >
              {category.charAt(0).toUpperCase() + category.slice(1)}
            </button>
          ))}
        </motion.div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" style={{ perspective: "2000px" }}>
          {filteredProducts.map((product, index) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
              whileHover={{ 
                rotateY: 5, 
                rotateX: -5,
                z: 50,
                transition: { duration: 0.4 }
              }}
              style={{ transformStyle: "preserve-3d" }}
            >
              <div
                className="relative overflow-hidden rounded-2xl transition-all duration-500"
                style={{
                  background: "linear-gradient(135deg, rgba(212, 175, 55, 0.25) 0%, rgba(229, 195, 127, 0.15) 50%, rgba(212, 175, 55, 0.25) 100%)",
                  backdropFilter: "blur(60px)",
                  border: "2px solid rgba(212, 175, 55, 0.5)",
                  boxShadow: `
                    0 8px 32px rgba(0, 0, 0, 0.6),
                    0 0 0 1px rgba(212, 175, 55, 0.3) inset,
                    0 20px 60px rgba(212, 175, 55, 0.2),
                    0 -5px 30px rgba(212, 175, 55, 0.1) inset,
                    0 5px 30px rgba(212, 175, 55, 0.15) inset
                  `,
                  transform: "translateZ(20px)"
                }}
              >
                {/* Multi-layered Liquid Glass Effect */}
                <div 
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    background: `
                      linear-gradient(125deg, transparent 0%, rgba(212, 175, 55, 0.4) 40%, transparent 60%),
                      linear-gradient(215deg, rgba(229, 195, 127, 0.3) 0%, transparent 50%),
                      radial-gradient(circle at 30% 30%, rgba(212, 175, 55, 0.25), transparent 60%)
                    `,
                    opacity: 0.7,
                    mixBlendMode: "screen"
                  }}
                />
                
                {/* Animated Gold Light Rays */}
                <motion.div
                  className="absolute inset-0 pointer-events-none"
                  style={{
                    background: "radial-gradient(ellipse at center, rgba(212, 175, 55, 0.4) 0%, transparent 70%)",
                    filter: "blur(20px)"
                  }}
                  animate={{
                    opacity: [0.3, 0.6, 0.3],
                    scale: [0.9, 1.1, 0.9]
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: index * 0.2
                  }}
                />

                {/* Gold Shine from Center */}
                <motion.div
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 pointer-events-none"
                  style={{
                    background: "radial-gradient(circle, rgba(212, 175, 55, 0.5) 0%, rgba(229, 195, 127, 0.3) 30%, transparent 70%)",
                    filter: "blur(40px)"
                  }}
                  animate={{
                    scale: [1, 1.3, 1],
                    opacity: [0.4, 0.7, 0.4]
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: index * 0.3
                  }}
                />

                {/* Featured Badge */}
                {product.featured && (
                  <div className="absolute top-4 right-4 z-10">
                    <span className="px-3 py-1 rounded-full bg-[#D4AF37] text-black text-xs uppercase tracking-wider"
                      style={{
                        boxShadow: "0 0 20px rgba(212, 175, 55, 0.6), 0 4px 15px rgba(0, 0, 0, 0.4)"
                      }}
                    >
                      Featured
                    </span>
                  </div>
                )}

                {/* Product Image */}
                <div className="relative h-64 overflow-hidden">
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  
                  {/* Gold Glow Overlay on Image */}
                  <div 
                    className="absolute inset-0 opacity-30 group-hover:opacity-50 transition-opacity duration-500"
                    style={{
                      background: "radial-gradient(circle at 50% 80%, rgba(212, 175, 55, 0.4), transparent 60%)",
                      mixBlendMode: "screen"
                    }}
                  />
                </div>

                {/* Product Info */}
                <div className="p-6 relative z-10">
                  <div className="mb-3">
                    <span className="text-[#D4AF37] text-xs uppercase tracking-wider">
                      {product.category}
                    </span>
                  </div>

                  <h3 className="text-2xl font-serif text-[#E5C37F] mb-2"
                    style={{
                      textShadow: "0 0 20px rgba(212, 175, 55, 0.3)"
                    }}
                  >
                    {product.name}
                  </h3>

                  <p className="text-[#E5C37F]/70 text-sm mb-4 line-clamp-2">
                    {product.description}
                  </p>

                  {/* Rating */}
                  <div className="flex items-center gap-1 mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className="w-4 h-4"
                        fill={i < product.rating ? "#D4AF37" : "none"}
                        stroke={i < product.rating ? "#D4AF37" : "#D4AF37"}
                        strokeWidth={1.5}
                        style={{
                          filter: i < product.rating ? "drop-shadow(0 0 4px rgba(212, 175, 55, 0.6))" : "none"
                        }}
                      />
                    ))}
                  </div>

                  {/* Price & Add to Cart */}
                  <div className="flex items-center justify-between pt-4 border-t border-[#D4AF37]/20">
                    <div>
                      <span className="text-3xl font-serif text-[#D4AF37]"
                        style={{
                          textShadow: "0 0 30px rgba(212, 175, 55, 0.5)"
                        }}
                      >
                        £{product.price}
                      </span>
                    </div>

                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => addToCart(product.id)}
                      className="flex items-center gap-2 px-5 py-3 rounded-full transition-all duration-300"
                      style={{
                        background: "linear-gradient(135deg, rgba(212, 175, 55, 0.3), rgba(229, 195, 127, 0.2))",
                        border: "1px solid rgba(212, 175, 55, 0.6)",
                        boxShadow: "0 4px 20px rgba(212, 175, 55, 0.3), 0 0 15px rgba(212, 175, 55, 0.2) inset"
                      }}
                    >
                      <ShoppingCart className="w-4 h-4 text-[#D4AF37]" />
                      <span className="text-[#E5C37F]">
                        Add
                      </span>
                    </motion.button>
                  </div>
                </div>

                {/* Enhanced Hover Glow Effect */}
                <motion.div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
                  style={{
                    background: `
                      radial-gradient(circle at 50% 50%, rgba(212, 175, 55, 0.3), transparent 60%),
                      linear-gradient(135deg, rgba(212, 175, 55, 0.2), rgba(229, 195, 127, 0.1))
                    `,
                    boxShadow: "0 0 60px rgba(212, 175, 55, 0.4) inset"
                  }}
                />
                
                {/* 3D Edge Highlights */}
                <div 
                  className="absolute inset-0 rounded-2xl pointer-events-none"
                  style={{
                    background: `
                      linear-gradient(to right, rgba(212, 175, 55, 0.4) 0%, transparent 20%),
                      linear-gradient(to left, rgba(212, 175, 55, 0.4) 0%, transparent 20%),
                      linear-gradient(to bottom, rgba(212, 175, 55, 0.3) 0%, transparent 15%),
                      linear-gradient(to top, rgba(212, 175, 55, 0.3) 0%, transparent 15%)
                    `,
                    opacity: 0.5
                  }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}