import { motion } from "motion/react";
import { Mail, MapPin, Phone } from "lucide-react";

export function ContactSection() {
  return (
    <section id="contact" className="py-32 px-6">
      <div className="max-w-4xl mx-auto relative">
        {/* Liquid glass backdrop glow */}
        <div 
          className="absolute inset-0 rounded-3xl opacity-30 blur-3xl"
          style={{
            background: "radial-gradient(circle at 50% 0%, rgba(212, 175, 55, 0.15), transparent 70%)"
          }}
        />
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16 relative z-10"
        >
          <h2 className="text-5xl md:text-6xl text-white font-serif mb-6">
            Contact Us
          </h2>
          <p className="text-xl text-[#E5C37F] opacity-80 font-[Abyssinica_SIL]">
            We'd love to hear from you. Reach out to our team.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2, duration: 0.8 }}
          className="glass-panel p-12 relative overflow-hidden"
          style={{
            background: "linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(212, 175, 55, 0.02))",
            backdropFilter: "blur(50px)",
            border: "1px solid rgba(212, 175, 55, 0.2)",
            boxShadow: "0 8px 32px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.1)"
          }}
        >
          {/* Liquid shimmer effect */}
          <div 
            className="absolute inset-0 opacity-20 pointer-events-none"
            style={{
              background: "linear-gradient(110deg, transparent 40%, rgba(212, 175, 55, 0.1) 50%, transparent 60%)",
              backgroundSize: "200% 100%",
              animation: "shimmer 8s ease-in-out infinite"
            }}
          />
          
          <div className="space-y-6 relative z-10">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <input
                type="text"
                placeholder="Full Name"
                className="px-6 py-4 rounded-2xl bg-[#1A1A1A] border border-[#D4AF37]/30 text-[#E5C37F] placeholder:text-[#E5C37F]/50 focus:outline-none focus:border-[#D4AF37] transition-colors"
              />
              <input
                type="email"
                placeholder="Email Address"
                className="px-6 py-4 rounded-2xl bg-[#1A1A1A] border border-[#D4AF37]/30 text-[#E5C37F] placeholder:text-[#E5C37F]/50 focus:outline-none focus:border-[#D4AF37] transition-colors"
              />
            </div>
            <input
              type="text"
              placeholder="Phone Number"
              className="w-full px-6 py-4 rounded-2xl bg-[#1A1A1A] border border-[#D4AF37]/30 text-[#E5C37F] placeholder:text-[#E5C37F]/50 focus:outline-none focus:border-[#D4AF37] transition-colors"
            />
            <textarea
              placeholder="How can we help you?"
              rows={5}
              className="w-full px-6 py-4 rounded-2xl bg-[#1A1A1A] border border-[#D4AF37]/30 text-[#E5C37F] placeholder:text-[#E5C37F]/50 focus:outline-none focus:border-[#D4AF37] transition-colors resize-none"
            />
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full glass-button"
              style={{
                background: "linear-gradient(135deg, rgba(212, 175, 55, 0.2), rgba(229, 195, 127, 0.1))",
                border: "1px solid rgba(212, 175, 55, 0.5)"
              }}
            >
              Send Message
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}