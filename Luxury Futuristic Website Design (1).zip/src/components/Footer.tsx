import { motion } from "motion/react";
import { ShoppingCart, Menu } from "lucide-react";
import { useState } from "react";
import logo from "figma:asset/bd97e12a8d048c1c32cdddf8e30c6d2dc3b41f46.png";

interface FooterProps {
  cartCount?: number;
  onCartClick?: () => void;
  onNavigate?: (page: "privacy" | "faq" | "contact") => void;
}

export function Footer({ cartCount = 0, onCartClick, onNavigate }: FooterProps) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <footer className="relative py-6 px-6">
      <div className="max-w-7xl mx-auto">
        {/* Liquid Glass Container */}
        <motion.div 
          whileHover={{ 
            scale: 1.01,
            boxShadow: "0 12px 48px 0 rgba(212, 175, 55, 0.25), inset 0 2px 0 0 rgba(255, 255, 255, 0.4)"
          }}
          transition={{ duration: 0.3 }}
          className="rounded-3xl px-6 py-4 relative overflow-hidden"
          style={{
            background: "rgba(255, 255, 255, 0.15)",
            backdropFilter: "blur(60px) saturate(180%)",
            border: "1px solid rgba(212, 175, 55, 0.4)",
            boxShadow: "0 8px 32px 0 rgba(212, 175, 55, 0.15), inset 0 1px 0 0 rgba(255, 255, 255, 0.4), inset 0 -1px 0 0 rgba(212, 175, 55, 0.2)"
          }}
        >
          {/* Glass reflection overlay */}
          <div 
            className="absolute inset-0 pointer-events-none"
            style={{
              background: "linear-gradient(135deg, rgba(255, 255, 255, 0.2) 0%, transparent 50%, rgba(212, 175, 55, 0.1) 100%)",
            }}
          />
          
          {/* Content */}
          <div className="relative z-10">
            {/* Compact Header - Logo, Cart, Menu */}
            <div className="flex items-center justify-between gap-4">
              {/* Logo and Brand */}
              <motion.div 
                className="flex items-center gap-3"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <div 
                  className="w-8 h-8 rounded-full overflow-hidden"
                  style={{
                    background: "rgba(255, 255, 255, 0.08)",
                    backdropFilter: "blur(20px)",
                    border: "1px solid rgba(255, 255, 255, 0.15)",
                    boxShadow: "0 4px 16px 0 rgba(255, 255, 255, 0.05)"
                  }}
                >
                  <img 
                    src={logo} 
                    alt="ELXAR" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl md:text-2xl text-white/90 font-serif tracking-[0.2em]">
                  ELXAR
                </h3>
              </motion.div>

              {/* Cart and Menu */}
              <div className="flex items-center gap-3">
                {/* Shopping Cart */}
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={onCartClick}
                  className="relative px-4 py-2 flex items-center gap-2 rounded-full"
                  style={{
                    background: "rgba(255, 255, 255, 0.08)",
                    backdropFilter: "blur(20px)",
                    border: "1px solid rgba(255, 255, 255, 0.15)"
                  }}
                >
                  <ShoppingCart className="w-4 h-4 text-white/70" />
                  <span className="text-white/70 text-sm hidden md:inline">Cart</span>
                  {cartCount > 0 && (
                    <span 
                      className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-xs text-white"
                      style={{
                        background: "rgba(255, 255, 255, 0.25)",
                        backdropFilter: "blur(10px)",
                        border: "1px solid rgba(255, 255, 255, 0.3)"
                      }}
                    >
                      {cartCount}
                    </span>
                  )}
                </motion.button>

                {/* Menu Button */}
                <div className="relative">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setMenuOpen(!menuOpen)}
                    className="px-4 py-2 flex items-center gap-2 rounded-full"
                    style={{
                      background: "rgba(255, 255, 255, 0.08)",
                      backdropFilter: "blur(20px)",
                      border: "1px solid rgba(255, 255, 255, 0.15)"
                    }}
                  >
                    <Menu className="w-4 h-4 text-white/70" />
                    <span className="text-white/70 text-sm hidden md:inline">Menu</span>
                  </motion.button>

                  {/* Dropdown Menu */}
                  {menuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="absolute top-full right-0 mt-2 rounded-2xl overflow-hidden"
                      style={{
                        background: "rgba(255, 255, 255, 0.1)",
                        backdropFilter: "blur(40px)",
                        border: "1px solid rgba(255, 255, 255, 0.2)",
                        boxShadow: "0 8px 32px 0 rgba(0, 0, 0, 0.3)",
                        minWidth: "180px"
                      }}
                    >
                      <button
                        onClick={() => {
                          onNavigate?.("privacy");
                          setMenuOpen(false);
                        }}
                        className="w-full px-5 py-2.5 text-left text-white/80 hover:bg-white/10 transition-colors text-sm"
                      >
                        Privacy Policy
                      </button>
                      <div className="h-px bg-white/10" />
                      <button
                        onClick={() => {
                          onNavigate?.("faq");
                          setMenuOpen(false);
                        }}
                        className="w-full px-5 py-2.5 text-left text-white/80 hover:bg-white/10 transition-colors text-sm"
                      >
                        Most Asked Questions
                      </button>
                      <div className="h-px bg-white/10" />
                      <button
                        onClick={() => {
                          onNavigate?.("contact");
                          setMenuOpen(false);
                        }}
                        className="w-full px-5 py-2.5 text-left text-white/80 hover:bg-white/10 transition-colors text-sm"
                      >
                        Contact
                      </button>
                    </motion.div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </footer>
  );
}
