import { motion } from "motion/react";
import { useState } from "react";
import { 
  Crown, 
  Calendar, 
  CreditCard, 
  Settings, 
  LogOut, 
  Sparkles,
  Video,
  Gift,
  TrendingUp
} from "lucide-react";

export function MemberDashboard() {
  const [activeTab, setActiveTab] = useState<"membership" | "access" | "culture" | "settings">("membership");
  
  const memberData = {
    name: "Alexander Sterling",
    tier: "Black",
    memberSince: "January 2025",
    renewalDate: "February 19, 2025",
    nextBilling: "£80.00"
  };

  return (
    <section className="min-h-screen py-24 px-6 bg-[#0A0A0A]">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h1 className="text-5xl text-white font-serif mb-2">
            Member Dashboard
          </h1>
          <p className="text-[#E5C37F]/70">
            Welcome back, {memberData.name}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-1"
          >
            <div className="glass-panel p-6 sticky top-24">
              {/* Membership Card */}
              <div 
                className="w-full aspect-[1.6/1] rounded-xl relative overflow-hidden mb-6 p-6 flex flex-col justify-between"
                style={{
                  background: "linear-gradient(135deg, rgba(212, 175, 55, 0.3), rgba(229, 195, 127, 0.2))",
                  border: "1px solid rgba(212, 175, 55, 0.5)",
                  backdropFilter: "blur(20px)",
                  boxShadow: "0 8px 32px rgba(212, 175, 55, 0.2)"
                }}
              >
                <div>
                  <p className="text-xs text-[#E5C37F]/70">MEMBER SINCE 2025</p>
                  <p className="text-2xl text-white font-serif mt-1">ELXAR</p>
                </div>
                <div className="text-right">
                  <p className="text-xl text-[#D4AF37] mb-1">{memberData.tier.toUpperCase()}</p>
                  <p className="text-sm text-[#E5C37F]/80">{memberData.name}</p>
                </div>
              </div>

              {/* Navigation */}
              <nav className="space-y-2">
                <button
                  onClick={() => setActiveTab("membership")}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    activeTab === "membership"
                      ? "bg-[#D4AF37]/20 text-[#E5C37F] border border-[#D4AF37]"
                      : "text-[#E5C37F]/60 hover:bg-[#161616]"
                  }`}
                >
                  <Crown className="w-5 h-5" />
                  <span>My Membership</span>
                </button>
                
                <button
                  onClick={() => setActiveTab("access")}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    activeTab === "access"
                      ? "bg-[#D4AF37]/20 text-[#E5C37F] border border-[#D4AF37]"
                      : "text-[#E5C37F]/60 hover:bg-[#161616]"
                  }`}
                >
                  <Sparkles className="w-5 h-5" />
                  <span>Exclusive Access</span>
                </button>
                
                <button
                  onClick={() => setActiveTab("culture")}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    activeTab === "culture"
                      ? "bg-[#D4AF37]/20 text-[#E5C37F] border border-[#D4AF37]"
                      : "text-[#E5C37F]/60 hover:bg-[#161616]"
                  }`}
                >
                  <Video className="w-5 h-5" />
                  <span>Culture Hub</span>
                </button>
                
                <button
                  onClick={() => setActiveTab("settings")}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    activeTab === "settings"
                      ? "bg-[#D4AF37]/20 text-[#E5C37F] border border-[#D4AF37]"
                      : "text-[#E5C37F]/60 hover:bg-[#161616]"
                  }`}
                >
                  <Settings className="w-5 h-5" />
                  <span>Settings</span>
                </button>

                <div className="h-px bg-[#D4AF37]/30 my-4" />
                
                <button className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-[#E5C37F]/60 hover:bg-[#161616] transition-all">
                  <LogOut className="w-5 h-5" />
                  <span>Sign Out</span>
                </button>
              </nav>
            </div>
          </motion.div>

          {/* Main Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-3"
          >
            {/* Membership Tab */}
            {activeTab === "membership" && (
              <div className="space-y-6">
                <div className="glass-panel p-8">
                  <h2 className="text-3xl text-white font-serif mb-6">
                    Membership Overview
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                    <div className="bg-[#161616] p-6 rounded-xl border border-[#D4AF37]/30">
                      <Calendar className="w-6 h-6 text-[#D4AF37] mb-3" />
                      <p className="text-sm text-[#E5C37F]/70 mb-1">Member Since</p>
                      <p className="text-xl text-[#E5C37F]">{memberData.memberSince}</p>
                    </div>
                    
                    <div className="bg-[#161616] p-6 rounded-xl border border-[#D4AF37]/30">
                      <CreditCard className="w-6 h-6 text-[#D4AF37] mb-3" />
                      <p className="text-sm text-[#E5C37F]/70 mb-1">Next Billing</p>
                      <p className="text-xl text-[#E5C37F]">{memberData.renewalDate}</p>
                      <p className="text-sm text-[#D4AF37] mt-1">{memberData.nextBilling}</p>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-[#D4AF37]/10 to-transparent p-6 rounded-xl border border-[#D4AF37]/30 mb-6">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-xl text-white mb-2">Current Plan: ELXAR {memberData.tier}</h3>
                        <p className="text-[#E5C37F]/80 mb-4">
                          You're enjoying all premium benefits of the {memberData.tier} tier
                        </p>
                        {memberData.tier === "Gold" && (
                          <motion.button
                            whileHover={{ scale: 1.05 }}
                            className="px-6 py-3 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#E5C37F] text-[#0A0A0A]"
                          >
                            Upgrade to Black
                          </motion.button>
                        )}
                      </div>
                      <TrendingUp className="w-8 h-8 text-[#D4AF37]" />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-xl text-white mb-4">Billing History</h3>
                    {[
                      { date: "Jan 19, 2025", amount: "£80.00", status: "Paid" },
                      { date: "Dec 19, 2024", amount: "£80.00", status: "Paid" },
                      { date: "Nov 19, 2024", amount: "£80.00", status: "Paid" }
                    ].map((invoice, i) => (
                      <div 
                        key={i}
                        className="flex items-center justify-between p-4 bg-[#161616] rounded-lg border border-[#D4AF37]/20"
                      >
                        <div>
                          <p className="text-[#E5C37F]">{invoice.date}</p>
                          <p className="text-sm text-[#E5C37F]/60">ELXAR {memberData.tier} Membership</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[#D4AF37]">{invoice.amount}</p>
                          <p className="text-xs text-green-400">{invoice.status}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Exclusive Access Tab */}
            {activeTab === "access" && (
              <div className="space-y-6">
                <div className="glass-panel p-8">
                  <h2 className="text-3xl text-white font-serif mb-6">
                    Exclusive Access
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {[
                      { title: "New Fragrance Launch", subtitle: "Limited Edition 2025", icon: Gift },
                      { title: "VIP Private Event", subtitle: "London • March 15", icon: Sparkles },
                      { title: "Member Pricing", subtitle: "Save up to 30%", icon: TrendingUp },
                      { title: "Fast-Track Access", subtitle: "Partner Venues Worldwide", icon: Crown }
                    ].map((item, i) => (
                      <motion.div
                        key={i}
                        whileHover={{ scale: 1.03 }}
                        className="p-6 bg-[#161616] rounded-xl border border-[#D4AF37]/30 cursor-pointer"
                      >
                        <item.icon className="w-8 h-8 text-[#D4AF37] mb-4" />
                        <h3 className="text-xl text-white mb-2">{item.title}</h3>
                        <p className="text-[#E5C37F]/70">{item.subtitle}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Culture Hub Tab */}
            {activeTab === "culture" && (
              <div className="space-y-6">
                <div className="glass-panel p-8">
                  <h2 className="text-3xl text-white font-serif mb-6">
                    Fragrance Culture Hub
                  </h2>
                  
                  <div className="space-y-6">
                    {[
                      { 
                        title: "The Art of Perfumery", 
                        type: "Video Series",
                        duration: "45 min"
                      },
                      { 
                        title: "2025 Fragrance Trends", 
                        type: "Exclusive Report",
                        duration: "15 min read"
                      },
                      { 
                        title: "Master Perfumer Interview", 
                        type: "Premium Content",
                        duration: "32 min"
                      }
                    ].map((content, i) => (
                      <motion.div
                        key={i}
                        whileHover={{ x: 10 }}
                        className="p-6 bg-[#161616] rounded-xl border border-[#D4AF37]/30 cursor-pointer flex items-center justify-between"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-lg bg-[#D4AF37]/20 flex items-center justify-center">
                            <Video className="w-6 h-6 text-[#D4AF37]" />
                          </div>
                          <div>
                            <h3 className="text-xl text-white">{content.title}</h3>
                            <p className="text-[#E5C37F]/70">{content.type} • {content.duration}</p>
                          </div>
                        </div>
                        <div className="w-10 h-10 rounded-full bg-[#D4AF37]/20 flex items-center justify-center">
                          <span className="text-[#D4AF37]">→</span>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Settings Tab */}
            {activeTab === "settings" && (
              <div className="space-y-6">
                <div className="glass-panel p-8">
                  <h2 className="text-3xl text-white font-serif mb-6">
                    Account Settings
                  </h2>
                  
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-xl text-white mb-4">Payment Method</h3>
                      <div className="p-6 bg-[#161616] rounded-xl border border-[#D4AF37]/30 flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <CreditCard className="w-6 h-6 text-[#D4AF37]" />
                          <div>
                            <p className="text-[#E5C37F]">•••• •••• •••• 4242</p>
                            <p className="text-sm text-[#E5C37F]/60">Expires 12/27</p>
                          </div>
                        </div>
                        <button className="px-6 py-2 rounded-full border border-[#D4AF37]/40 text-[#E5C37F] hover:border-[#D4AF37] transition-all">
                          Update
                        </button>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-xl text-white mb-4">Membership Actions</h3>
                      <div className="space-y-3">
                        <button className="w-full p-4 rounded-xl border border-[#D4AF37]/30 text-[#E5C37F] hover:bg-[#161616] transition-all text-left">
                          Pause Membership
                        </button>
                        <button className="w-full p-4 rounded-xl border border-red-500/30 text-red-400 hover:bg-red-500/10 transition-all text-left">
                          Cancel Membership
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
