import { motion, useScroll, useTransform } from "motion/react";
import { Crown, Gem } from "lucide-react";
import { useRef, useState } from "react";

interface MembershipTiersProps {
  onJoinClick?: (tier: "gold" | "black") => void;
}

const tiers = [
  {
    name: "ELXAR Gold",
    icon: Crown,
    priceMonthly: "£40",
    priceYearly: "£400",
    period: "per month",
    features: [
      "Exclusive fragrance drops",
      "Members-only pricing",
      "Limited access to ELXAR private events",
      "Monthly curated content",
      "Digital membership card",
      "Priority customer support"
    ],
    gradient: "from-[#161616] to-[#1A1A1A]",
    borderStyle: "1px solid rgba(212, 175, 55, 0.3)"
  },
  {
    name: "ELXAR Black",
    icon: Gem,
    priceMonthly: "£80",
    priceYearly: "£800",
    period: "per month",
    features: [
      "All Gold perks",
      "Priority access to launches",
      "VIP private events",
      "Premium digital content",
      "Fast-track entry at partnered venues",
      "Exclusive Black member experiences",
      "Upgrade to Black anytime"
    ],
    gradient: "from-[#D4AF37]/20 to-[#E5C37F]/10",
    featured: true,
    borderStyle: "1px solid rgba(212, 175, 55, 0.6)"
  }
];

export function MembershipTiers({ onJoinClick }: MembershipTiersProps) {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  
  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  return (
    <section ref={ref} className="py-32 px-6" id="membership">
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="max-w-7xl mx-auto"
      >
        <div className="text-center mb-16">
          <h2 className="text-5xl md:text-6xl text-white font-serif mb-6">
            Membership Structure
          </h2>
          <p className="text-xl text-[#E5C37F] opacity-80 max-w-2xl mx-auto mb-8">
            Choose the tier that elevates your fragrance and luxury experience
          </p>
          
          {/* Billing Toggle */}
          <div className="flex justify-center items-center gap-4 mt-8">
            <button
              onClick={() => setBillingCycle("monthly")}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                billingCycle === "monthly"
                  ? "bg-[#D4AF37]/20 text-[#E5C37F] border border-[#D4AF37]"
                  : "text-[#E5C37F]/60 border border-[#D4AF37]/30"
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setBillingCycle("yearly")}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                billingCycle === "yearly"
                  ? "bg-[#D4AF37]/20 text-[#E5C37F] border border-[#D4AF37]"
                  : "text-[#E5C37F]/60 border border-[#D4AF37]/30"
              }`}
            >
              Yearly
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {tiers.map((tier, index) => (
            <motion.div
              key={tier.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.2, duration: 0.8 }}
              style={tier.featured ? { y } : undefined}
            >
              <motion.div
                whileHover={{ 
                  scale: 1.03,
                  rotateY: 2,
                  z: 50
                }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className={`tier-card ${tier.featured ? 'featured-tier' : ''} relative`}
                style={{ 
                  transformStyle: "preserve-3d",
                  border: tier.borderStyle
                }}
              >
                {tier.featured && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-6 py-2 rounded-full bg-gradient-to-r from-[#D4AF37] to-[#E5C37F] text-[#0A0A0A]">
                    Elite Tier
                  </div>
                )}
                
                <div className="relative p-8 space-y-6">
                  {/* Icon in glass cube */}
                  <div className="flex justify-center mb-6">
                    <div className="relative w-20 h-20">
                      <div 
                        className="absolute inset-0 rounded-xl"
                        style={{
                          background: tier.featured 
                            ? "rgba(212, 175, 55, 0.15)"
                            : "rgba(255,255,255,0.05)",
                          backdropFilter: "blur(20px)",
                          border: tier.featured 
                            ? "1px solid rgba(212,175,55,0.5)"
                            : "1px solid rgba(212,175,55,0.3)",
                          boxShadow: "0 8px 32px 0 rgba(212,175,55,0.15)"
                        }}
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <tier.icon className="w-10 h-10 text-[#D4AF37]" />
                      </div>
                    </div>
                  </div>

                  <h3 className="text-3xl text-white font-serif text-center">
                    {tier.name}
                  </h3>
                  
                  <div className="text-center">
                    <p className="text-5xl text-[#E5C37F] mb-2">
                      {billingCycle === "monthly" ? tier.priceMonthly : tier.priceYearly}
                    </p>
                    <p className="text-sm text-[#E5C37F]/60">
                      {billingCycle === "monthly" ? "per month" : "per year"}
                    </p>
                    <p className="text-xs text-[#E5C37F]/50 mt-1">
                      Billing renews {billingCycle}. Cancel anytime.
                    </p>
                  </div>
                  
                  <div className="h-px bg-gradient-to-r from-transparent via-[#D4AF37] to-transparent opacity-30" />
                  
                  <ul className="space-y-3 min-h-[220px]">
                    {tier.features.map((feature, i) => (
                      <li key={i} className="text-[#E5C37F] opacity-90 flex items-start gap-3">
                        <div className="w-1.5 h-1.5 rounded-full bg-[#D4AF37] mt-2 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="glass-button w-full"
                    style={{
                      background: tier.featured
                        ? "linear-gradient(135deg, rgba(212, 175, 55, 0.3), rgba(229, 195, 127, 0.2))"
                        : "linear-gradient(135deg, rgba(212, 175, 55, 0.15), rgba(229, 195, 127, 0.1))",
                      border: tier.featured
                        ? "1px solid rgba(212, 175, 55, 0.6)"
                        : "1px solid rgba(212, 175, 55, 0.4)"
                    }}
                    onClick={() => onJoinClick?.(tier.name.includes("Gold") ? "gold" : "black")}
                  >
                    Join {tier.name}
                  </motion.button>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}