import { motion } from "motion/react";
import { Globe, Shield, Sparkles, Users } from "lucide-react";

const features = [
  {
    icon: Globe,
    title: "Global Access",
    description: "Exclusive access to 500+ luxury venues worldwide, from private clubs to premium resorts."
  },
  {
    icon: Shield,
    title: "VIP Concierge",
    description: "24/7 dedicated concierge service to handle all your lifestyle needs with discretion."
  },
  {
    icon: Sparkles,
    title: "Curated Experiences",
    description: "Bespoke luxury experiences tailored to your preferences, from private jets to yacht charters."
  },
  {
    icon: Users,
    title: "Elite Network",
    description: "Connect with a global community of distinguished members and industry leaders."
  }
];

export function ExclusiveFeatures() {
  return (
    <section id="benefits" className="py-32 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="text-5xl md:text-6xl text-white font-serif mb-6">
            Exclusive Benefits
          </h2>
          <p className="text-xl text-[#E5C37F] opacity-80 max-w-2xl mx-auto">
            Experience unparalleled luxury and access to a world of extraordinary privileges
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.6 }}
            >
              <motion.div
                whileHover={{ scale: 1.02, y: -5 }}
                className="glass-panel p-8 h-full"
                style={{
                  background: "rgba(255, 255, 255, 0.03)",
                  backdropFilter: "blur(40px)"
                }}
              >
                <div className="flex items-start gap-6">
                  <div className="flex-shrink-0 pt-1">
                    <feature.icon className="w-8 h-8 text-[#D4AF37]" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl text-white font-serif mb-3">
                      {feature.title}
                    </h3>
                    <p className="text-[#E5C37F] opacity-80 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}