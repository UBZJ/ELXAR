# ELXAR - Luxury Fragrances & Exclusive Membership

A sophisticated, futuristic luxury website featuring 3D elements, liquid-glass panels, and gold accents inspired by Apple Vision Pro, Rolls-Royce luxury, and high-end private membership clubs.

## 🚀 Quick Start

### Development
```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

### Production Build
```bash
# Build for production
npm run build

# Preview production build
npm run preview
```

## 🌐 Deployment Options

### Option 1: Vercel (Recommended)
1. Push code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your repository
4. Deploy automatically

### Option 2: Netlify
1. Push code to GitHub
2. Go to [netlify.com](https://netlify.com)
3. Import your repository
4. Build command: `npm run build`
5. Publish directory: `dist`

### Option 3: Manual Hosting
1. Run `npm run build`
2. Upload the `dist` folder to your web host
3. Configure your server to serve `index.html` for all routes

## 🎨 Features

- **Liquid Glass Effects**: Advanced glassmorphism with 3D depth
- **Gold Accents**: Luxury highlighting with animated shimmer
- **3D Product Cards**: Interactive cards with perspective tilt
- **Responsive Design**: Mobile-first approach
- **Smooth Animations**: Motion-driven interactions
- **Shopping Cart**: Full product management
- **Membership Tiers**: Gold (£40/month) and Black (£80/month)

## 📦 Tech Stack

- **React 18** - UI Framework
- **TypeScript** - Type Safety
- **Vite** - Build Tool
- **Tailwind CSS 4** - Styling
- **Motion** (Framer Motion) - Animations
- **Lucide React** - Icons

## 🎯 Current Status

✅ Fully functional frontend
✅ Mock payment flow
✅ Product catalog with cart
✅ Membership signup flow
✅ Responsive navigation
✅ Contact, FAQ, Privacy pages

⚠️ **Not Yet Implemented:**
- Real payment processing (needs Stripe integration)
- Backend database (needs Supabase or similar)
- User authentication
- Email notifications
- Order management

## 🔧 Next Steps for Full Launch

1. **Set up Stripe** for payment processing
2. **Implement Supabase** for database and auth
3. **Add Terms & Conditions** page
4. **Configure custom domain**
5. **Set up email service** (SendGrid, Mailgun)
6. **Add analytics** (Google Analytics, Plausible)

## 📄 License

Private - All Rights Reserved © ELXAR

## 🆘 Support

For deployment help or custom features, contact your developer.
